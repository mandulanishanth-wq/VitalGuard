# VitalGuard

**A smart wearable device that continuously monitors vital health parameters and detects falls using multiple sensors integrated with an ESP32 microcontroller.**

VitalGuard sends real-time health data to a live web dashboard hosted directly on the device, and tracks the wearer's GPS location against a defined safe zone (geofence) — enabling remote monitoring and timely alerts for caregivers.

🔗 **Live Demo Page:** [https://mandulanishanth-wq.github.io/VitalGuard/](https://mandulanishanth-wq.github.io/VitalGuard/)

![VitalGuard Dashboard](img/img-6.jpeg)

---

## 📖 Overview

VitalGuard is a wearable ESP32-based health and safety monitor. It reads heart rate and blood oxygen levels, detects falls using an accelerometer, and tracks GPS location against a virtual safe zone — all displayed locally on an OLED screen and live on a web dashboard served directly from the device over Wi-Fi.

## ✨ Features

- ❤️ **Heart Rate (BPM) Monitoring** — using a MAX30105 pulse/oximeter sensor with peak-detection and rolling-average smoothing
- 🩸 **SpO2 (Blood Oxygen) Estimation** — calculated from red/IR light absorption ratios
- 🚨 **Fall Detection** — using an MPU6050 accelerometer, triggered when total acceleration magnitude crosses a threshold
- 🗺️ **Geofencing** — checks the wearer's live GPS coordinates against a custom-defined safe zone using a point-in-polygon (angle-sum) algorithm
- 📟 **On-device OLED Display** — shows BPM, SpO2, and zone status locally on a SH1106 128x64 display
- 🌐 **Live Web Dashboard** — the ESP32 hosts its own webpage, auto-refreshing every second via JSON polling — no external server required

## 🛠️ Hardware Used

| Component | Purpose |
|---|---|
| ESP32 Dev Board | Main microcontroller, Wi-Fi + web server |
| MAX30105 | Heart rate (BPM) and SpO2 sensor |
| MPU6050 | Accelerometer for fall detection |
| SH1106 OLED (128x64, I2C) | Local status display |
| GPS Module (UART, e.g. NEO-6M) | Location tracking for geofencing |

![Hardware Setup](img/img-1.jpeg)

### Wiring

| Signal | ESP32 Pin |
|---|---|
| I2C SDA (OLED + MAX30105) | GPIO 21 |
| I2C SCL (OLED + MAX30105) | GPIO 22 |
| GPS RX (ESP32 receives from GPS TX) | GPIO 16 |
| GPS TX (ESP32 transmits to GPS RX) | GPIO 17 |
| GPS Baud Rate | 9600 |
| OLED I2C Address | 0x3C |

## 📦 Libraries Required

Install these via the Arduino Library Manager:

- `Wire` (built-in)
- `WiFi` (built-in, ESP32 core)
- `WebServer` (built-in, ESP32 core)
- `MAX30105` (SparkFun MAX3010x Pulse and Proximity Sensor Library)
- `Adafruit_GFX`
- `Adafruit_SH110X`
- `MPU6050` (e.g. by Electronic Cats / jrowberg i2cdevlib)
- `TinyGPS++`

## 🚀 Getting Started

### 1. Clone the repository

```bash
git clone https://github.com/mandulanishanth-wq/VitalGuard.git
cd VitalGuard
```

### 2. Configure Wi-Fi credentials

In `VitalGuard.ino`, update:

```cpp
const char* ssid = "YOUR_WIFI";
const char* password = "YOUR_PASS";
```

### 3. Set your geofence coordinates

Replace the `fence[][]` array with the latitude/longitude points that define your own safe zone (drawn as a polygon).

### 4. Flash the firmware

Open `VitalGuard.ino` in the Arduino IDE (or PlatformIO), select your ESP32 board, install the libraries above, and upload.

### 5. View the dashboard

Open the Serial Monitor after boot to see the device's IP address, then visit that IP in a browser on the same network:

```
http://<ESP32_IP_ADDRESS>/
```

The dashboard auto-refreshes every second and shows BPM, SpO2, fall status, geofence status, and live GPS coordinates.

![Live Dashboard View](img/img-5.jpeg)

## 📊 How It Works

- **Heart Rate:** Peaks in the IR signal from the MAX30105 are detected and timed to compute instantaneous BPM, smoothed with a 5-sample rolling average.
- **SpO2:** Estimated from the AC/DC ratio of red vs. infrared light absorption.
- **Fall Detection:** The MPU6050's 3-axis acceleration magnitude is compared against a threshold (`FALL_THRESHOLD`); crossing it latches a "FALL DETECTED" state.
- **Geofencing:** Uses an angle-summation point-in-polygon method — summing the angles between the current GPS position and each edge of the defined fence polygon to determine if the point lies inside (~360°) or outside.

## 🗺️ Roadmap

- [ ] Push notifications / SMS alerts (e.g. via IFTTT or a messaging API) instead of dashboard-only alerts
- [ ] Cloud data logging and history (Firebase or similar)
- [ ] Mobile app for caregivers
- [ ] Battery level monitoring for the wearable

## 🤝 Contributing

Contributions are welcome! Feel free to open an issue or submit a pull request with improvements, bug fixes, or new features.

## 📄 License

This project is open source. Add your preferred license (e.g., MIT) here.

## 📬 Contact

For questions or feedback, open an issue on this repository.
